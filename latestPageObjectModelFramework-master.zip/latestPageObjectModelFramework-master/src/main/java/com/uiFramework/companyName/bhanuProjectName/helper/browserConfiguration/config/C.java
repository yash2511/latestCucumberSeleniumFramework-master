package com.uiFramework.companyName.bhanuProjectName.helper.browserConfiguration.config;

public class C {

	public static A reader;
}
