package com.uiFramework.companyName.bhanuProjectName.helper.browserConfiguration.config;
/**
 * 
 * @author Bhanu Pratap Singh
 *
 */
public interface A {

	
	void test1();
	void test2();
}
