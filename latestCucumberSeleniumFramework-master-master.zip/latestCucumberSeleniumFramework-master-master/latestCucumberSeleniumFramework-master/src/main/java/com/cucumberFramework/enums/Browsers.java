package com.cucumberFramework.enums;

/**
 * 
 * @author Bhanu Pratap Singh
 * https://www.udemy.com/seleniumbybhanu/
 * https://www.youtube.com/user/MrBhanupratap29/playlists
 *
 */
public enum Browsers {
	
	CHROME,
	FIREFOX,
	IE

}
