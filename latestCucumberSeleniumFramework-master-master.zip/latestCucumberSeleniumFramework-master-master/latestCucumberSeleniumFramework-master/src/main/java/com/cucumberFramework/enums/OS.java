package com.cucumberFramework.enums;

public enum OS {
	
	WINDOW,
	MAC

}
